import abi from "./Transactions.json";
export const contractABI = abi.abi;
export const contractAddress = "0x249a75B134036558884E65746deb8aa2926BB875";
