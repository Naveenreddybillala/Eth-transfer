# ethtransfer

Built EthTransfer app for secure Ethereum transactions. Used Vite, Solidity, React. 2023-2023.
